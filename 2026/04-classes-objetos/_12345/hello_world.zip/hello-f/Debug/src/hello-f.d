src/hello-f.o: ../src/hello-f.cpp ../src/Point.h ../src/Rectangle.h
../src/Point.h:
../src/Rectangle.h:
