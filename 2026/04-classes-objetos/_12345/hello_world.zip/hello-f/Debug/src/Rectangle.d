src/Rectangle.o: ../src/Rectangle.cpp ../src/Rectangle.h ../src/Point.h
../src/Rectangle.h:
../src/Point.h:
