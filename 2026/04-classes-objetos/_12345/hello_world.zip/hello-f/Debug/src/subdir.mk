################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/Point.cpp \
../src/Rectangle.cpp \
../src/hello-f.cpp 

CPP_DEPS += \
./src/Point.d \
./src/Rectangle.d \
./src/hello-f.d 

OBJS += \
./src/Point.o \
./src/Rectangle.o \
./src/hello-f.o 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.cpp src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src

clean-src:
	-$(RM) ./src/Point.d ./src/Point.o ./src/Rectangle.d ./src/Rectangle.o ./src/hello-f.d ./src/hello-f.o

.PHONY: clean-src

